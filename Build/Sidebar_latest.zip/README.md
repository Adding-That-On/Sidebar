This is the output folder with the output from the build.
