# Sidebar
Easily open your favourite websites from the sidebar!
